// Take to Screan2
onEvent("Search_button", "click", function( ) {
  setScreen("Carstartersearch");
});
//Take to Car_screen_search
onEvent("Model_car_search", "click", function( ) {
  setScreen("Car_search_screen");
});
//Take to Sympotoms_car
onEvent("Symptoms_car", "click", function( ) {
  setScreen("Car_symptom_page");
});
// take to Carstarterscreen
onEvent("Return_to_front_page", "click", function( ) {
  setScreen("CarstarterScreen");
});
//Take to Carstartersearch 
onEvent("Carstartercarsforsalescrean", "click", function( ) {
  setScreen("Carstartersearch");
});
//take to Carstarterscreen
onEvent("Carstartersymptomsbackbutton", "click", function( ) {
  setScreen("CarstarterScreen");
});
